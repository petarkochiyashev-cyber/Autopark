import { query } from "@/lib/db";

export async function writeAudit(input: {
  actorUserId: string;
  action: string;
  entityType: string;
  entityId?: string | null;
  companyId?: string | null;
  details?: Record<string, unknown>;
}) {
  await query(
    `insert into audit_log(actor_user_id,action,entity_type,entity_id,company_id,details)
     values($1,$2,$3,$4,$5,$6::jsonb)`,
    [
      input.actorUserId,
      input.action,
      input.entityType,
      input.entityId || null,
      input.companyId || null,
      JSON.stringify(input.details || {}),
    ]
  );
}
