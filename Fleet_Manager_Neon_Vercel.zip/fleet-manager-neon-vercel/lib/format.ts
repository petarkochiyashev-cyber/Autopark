export function formatBGN(value: number | string | null | undefined) {
  return new Intl.NumberFormat("bg-BG", {
    style: "currency",
    currency: "BGN",
  }).format(Number(value || 0));
}

export function formatDate(value: string | null | undefined) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("bg-BG").format(new Date(value));
}

export function documentStatus(endDate: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const end = new Date(endDate);
  end.setHours(0, 0, 0, 0);
  const days = Math.ceil((end.getTime() - today.getTime()) / 86400000);
  if (days < 0) return { key: "expired", label: "Изтекъл", days };
  if (days <= 7) return { key: "urgent", label: `${days} дни`, days };
  if (days <= 30) return { key: "soon", label: `${days} дни`, days };
  return { key: "valid", label: "Валиден", days };
}
