import { query } from "@/lib/db";
import { accessibleCompanyIds } from "@/lib/session";

export async function companyScope(userId:string,role:string){
 const ids=await accessibleCompanyIds(userId,role);
 return {ids,params:ids,clause:ids.length?`company_id = any($1::uuid[])`:"false"};
}
