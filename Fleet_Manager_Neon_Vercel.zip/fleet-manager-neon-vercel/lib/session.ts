import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { one, query } from "@/lib/db";

export type AppProfile = {
  user_id: string;
  email: string;
  full_name: string;
  global_role: "main_admin" | "company_manager" | "editor" | "driver" | "viewer";
  active: boolean;
  notification_channels: Record<string, boolean>;
  last_password_action_at: string | null;
};

export async function getSessionContext() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) return null;

  const profile = await one<AppProfile>(
    `select user_id,email,full_name,global_role,active,notification_channels,last_password_action_at
     from app_profiles where user_id=$1`,
    [session.user.id]
  );
  if (!profile?.active) return null;
  return { session, profile };
}

export async function requireUser() {
  const ctx = await getSessionContext();
  if (!ctx) redirect("/login");
  return ctx;
}

export async function requireMainAdmin() {
  const ctx = await requireUser();
  if (ctx.profile.global_role !== "main_admin") {
    throw new Error("Само главният администратор има достъп.");
  }
  return ctx;
}

export async function accessibleCompanyIds(userId: string, role: string) {
  if (role === "main_admin") {
    const rows = await query<{ id: string }>("select id from companies where active=true");
    return rows.map((r) => r.id);
  }
  const rows = await query<{ company_id: string }>(
    `select company_id from company_users
     where user_id=$1 and active=true`,
    [userId]
  );
  return rows.map((r) => r.company_id);
}

export async function canManageCompany(
  userId: string,
  globalRole: string,
  companyId: string,
  permission: string
) {
  if (globalRole === "main_admin") return true;
  const row = await one<{ allowed: boolean }>(
    `select (
       role in ('company_manager','editor')
       or coalesce((permissions ->> $3)::boolean,false)
     ) as allowed
     from company_users
     where user_id=$1 and company_id=$2 and active=true`,
    [userId, companyId, permission]
  );
  return Boolean(row?.allowed);
}
