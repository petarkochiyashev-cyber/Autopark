import "dotenv/config";import fs from "node:fs";import pg from "pg";
const sql=fs.readFileSync("db/seed.sql","utf8");const client=new pg.Client({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false}});await client.connect();await client.query(sql);await client.end();console.log("Demo data inserted.");
