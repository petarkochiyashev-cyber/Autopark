import "dotenv/config";import {betterAuth} from "better-auth";import {admin} from "better-auth/plugins";import pg from "pg";
const [email,password,...parts]=process.argv.slice(2),name=parts.join(" ")||"Главен администратор";
if(!email||!password){console.error('Използване: npm run create-admin -- admin@example.com "StrongPass1!" "Име Фамилия"');process.exit(1)}
const pool=new pg.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false}});
const auth=betterAuth({database:pool,baseURL:process.env.BETTER_AUTH_URL,secret:process.env.BETTER_AUTH_SECRET,emailAndPassword:{enabled:true,disableSignUp:true},plugins:[admin({adminRoles:["admin"]})]});
const created=await auth.api.createUser({body:{email,password,name,role:"admin"}});await pool.query(`insert into app_profiles(user_id,email,full_name,global_role,active,last_password_action_at) values($1,$2,$3,'main_admin',true,now()) on conflict(user_id) do update set global_role='main_admin',active=true`,[created.user.id,email,name]);await pool.end();console.log(`Създаден главен администратор: ${email}`);
