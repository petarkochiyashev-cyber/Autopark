insert into companies(id,name,eik,address,manager_name,phone,email) values
('11111111-1111-1111-1111-111111111111','Атинапак Груп ЕООД','BG206137164','София, Манастирски ливади Б','Петър Кочияшев','0895 788444','office@atinapack.com'),
('22222222-2222-2222-2222-222222222222','Компания 2 ЕООД','BG200000002','София','Управител 2','','office2@example.com'),
('33333333-3333-3333-3333-333333333333','Компания 3 ЕООД','BG200000003','Пловдив','Управител 3','','office3@example.com')
on conflict(id) do nothing;

insert into vehicles(id,company_id,registration_number,make,model,vin,year,vehicle_type,ownership_type,mileage,status) values
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa1','11111111-1111-1111-1111-111111111111','СВ 1234 АВ','Ford','Transit','WF0XXXTTGXNA12345',2022,'Бус','Собствен',78450,'active'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa2','11111111-1111-1111-1111-111111111111','СА 5678 КК','Volkswagen','Caddy','WVWZZZ2KZMX123456',2021,'Лек автомобил','Лизинг',96520,'service'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa3','22222222-2222-2222-2222-222222222222','СВ 9012 ММ','Skoda','Superb','TMBLJ7NP0M7012345',2023,'Лек автомобил','Собствен',42100,'active')
on conflict(id) do nothing;

insert into vehicle_documents(company_id,vehicle_id,document_type,document_number,provider,start_date,end_date,cost) values
('11111111-1111-1111-1111-111111111111','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa1','civil_liability','GO-2026-001','Застраховател АД','2026-01-15','2026-08-12',410),
('11111111-1111-1111-1111-111111111111','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa1','vignette','BG-VIN-8842','АПИ','2025-07-25','2026-07-25',97),
('11111111-1111-1111-1111-111111111111','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa2','technical_inspection','GTP-4991','Автотест','2025-08-02','2026-08-02',70),
('22222222-2222-2222-2222-222222222222','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa3','casco','KASKO-8331','Застраховател АД','2026-03-10','2027-03-10',1240);
