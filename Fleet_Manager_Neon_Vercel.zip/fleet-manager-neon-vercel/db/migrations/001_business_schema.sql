create extension if not exists pgcrypto;

do $$ begin
 create type app_global_role as enum('main_admin','company_manager','editor','driver','viewer');
exception when duplicate_object then null; end $$;

create table if not exists app_profiles(
 user_id text primary key,
 email text not null unique,
 full_name text not null,
 global_role app_global_role not null default 'viewer',
 active boolean not null default true,
 notification_channels jsonb not null default '{"app":true,"email":true,"sms":false}',
 last_password_action_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists companies(
 id uuid primary key default gen_random_uuid(),name text not null,eik text,address text,manager_name text,phone text,email text,logo_path text,
 active boolean not null default true,created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);

create table if not exists company_users(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references companies(id) on delete cascade,user_id text not null references app_profiles(user_id) on delete cascade,
 role app_global_role not null default 'viewer',permissions jsonb not null default '{}',active boolean not null default true,created_at timestamptz not null default now(),unique(company_id,user_id)
);

create table if not exists vehicles(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references companies(id) on delete cascade,registration_number text not null,make text not null,model text not null,
 vin text,year int,vehicle_type text,ownership_type text,assigned_driver_user_id text references app_profiles(user_id) on delete set null,mileage int not null default 0 check(mileage>=0),
 status text not null default 'active' check(status in('active','service','inactive','sold')),photo_path text,notes text,created_by text references app_profiles(user_id),
 created_at timestamptz not null default now(),updated_at timestamptz not null default now(),unique(company_id,registration_number),unique(company_id,vin)
);

create table if not exists vehicle_documents(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references companies(id) on delete cascade,vehicle_id uuid not null references vehicles(id) on delete cascade,
 document_type text not null,document_number text,provider text,start_date date,end_date date not null,cost numeric(12,2) not null default 0,file_path text,notes text,
 created_by text references app_profiles(user_id),created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);

create table if not exists service_records(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references companies(id) on delete cascade,vehicle_id uuid not null references vehicles(id) on delete cascade,
 service_date date not null,mileage int,provider text,work_performed text not null,parts text,cost numeric(12,2) not null default 0,next_service_date date,next_service_mileage int,
 invoice_path text,notes text,created_by text references app_profiles(user_id),created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);

create table if not exists expenses(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references companies(id) on delete cascade,vehicle_id uuid references vehicles(id) on delete set null,
 expense_date date not null,category text not null,supplier text,gross_amount numeric(12,2) not null check(gross_amount>=0),currency text not null default 'BGN',
 document_path text,notes text,created_by text references app_profiles(user_id),created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);

create table if not exists driver_profiles(
 id uuid primary key default gen_random_uuid(),user_id text not null unique references app_profiles(user_id) on delete cascade,assigned_vehicle_id uuid references vehicles(id) on delete set null,
 phone text,license_categories text[] not null default '{}',license_expiry date,notes text,created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);

create table if not exists messages(
 id uuid primary key default gen_random_uuid(),sender_user_id text not null references app_profiles(user_id),company_id uuid references companies(id) on delete set null,
 subject text not null,body text not null,priority text not null default 'normal' check(priority in('normal','high','critical')),target_type text not null check(target_type in('user','role','company')),
 target_value text not null,created_at timestamptz not null default now()
);

create table if not exists message_recipients(
 id uuid primary key default gen_random_uuid(),message_id uuid not null references messages(id) on delete cascade,user_id text not null references app_profiles(user_id) on delete cascade,
 read_at timestamptz,unique(message_id,user_id)
);

create table if not exists audit_log(
 id bigint generated always as identity primary key,actor_user_id text references app_profiles(user_id) on delete set null,company_id uuid references companies(id) on delete set null,
 action text not null,entity_type text not null,entity_id text,details jsonb not null default '{}',created_at timestamptz not null default now()
);

create table if not exists notifications(
 id uuid primary key default gen_random_uuid(),user_id text not null references app_profiles(user_id) on delete cascade,company_id uuid references companies(id) on delete cascade,
 vehicle_document_id uuid references vehicle_documents(id) on delete cascade,title text not null,body text not null,reminder_days int,read_at timestamptz,created_at timestamptz not null default now(),
 unique(user_id,vehicle_document_id,reminder_days)
);

create index if not exists idx_company_users_user on company_users(user_id,active);
create index if not exists idx_vehicles_company on vehicles(company_id,status);
create index if not exists idx_documents_company_end on vehicle_documents(company_id,end_date);
create index if not exists idx_service_company_date on service_records(company_id,service_date desc);
create index if not exists idx_expenses_company_date on expenses(company_id,expense_date desc);
create index if not exists idx_audit_company_date on audit_log(company_id,created_at desc);
create index if not exists idx_recipients_user on message_recipients(user_id,read_at);

create or replace function generate_document_notifications() returns integer language plpgsql as $$
declare inserted_count integer;
begin
 insert into notifications(user_id,company_id,vehicle_document_id,title,body,reminder_days)
 select distinct cu.user_id,d.company_id,d.id,'Изтичащ документ',
 concat('Документът ',d.document_type,' за автомобил ',v.registration_number,' изтича на ',to_char(d.end_date,'DD.MM.YYYY')),
 (d.end_date-current_date)
 from vehicle_documents d join vehicles v on v.id=d.vehicle_id join company_users cu on cu.company_id=d.company_id and cu.active
 where (d.end_date-current_date) in(30,14,7,1)
 on conflict do nothing;
 get diagnostics inserted_count=row_count;return inserted_count;
end $$;
