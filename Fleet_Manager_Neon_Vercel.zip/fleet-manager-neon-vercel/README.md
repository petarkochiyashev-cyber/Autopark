# Fleet Manager — Neon + Vercel

Този вариант **не използва Supabase и не използва Lovable**.

## Архитектура

- Next.js във Вашия GitHub
- Vercel за хостинг
- Neon PostgreSQL през Vercel Marketplace
- Better Auth за потребители, пароли и сесии
- Vercel Blob за частни документи и снимки

## 1. Създаване на проекта във Vercel

1. Качете папката в ново GitHub repository.
2. Във Vercel изберете **Add New → Project** и импорт на repository.
3. В проекта отворете **Storage / Marketplace**.
4. Добавете **Neon Postgres**.
5. Vercel ще създаде `DATABASE_URL` автоматично.
6. Добавете **Vercel Blob** с Private access. Vercel ще създаде `BLOB_READ_WRITE_TOKEN`.

Vercel Postgres вече не се предлага като отделен продукт; новите PostgreSQL бази се добавят чрез Marketplace доставчик като Neon.

## 2. Environment Variables

Копирайте `.env.example` в `.env.local`:

```env
DATABASE_URL=postgresql://...
BETTER_AUTH_SECRET=дълъг-случаен-секрет
BETTER_AUTH_URL=http://localhost:3000
NEXT_PUBLIC_APP_URL=http://localhost:3000
BLOB_READ_WRITE_TOKEN=...
```

За Production:
- `BETTER_AUTH_URL=https://вашият-домейн`
- `NEXT_PUBLIC_APP_URL=https://вашият-домейн`

Генериране на секрет:

```bash
openssl rand -base64 32
```

## 3. Инсталация и база

```bash
npm install
npm run auth:migrate
npm run db:migrate
npm run db:seed
```

`auth:migrate` създава защитените Better Auth таблици за потребители, акаунти и сесии.
`db:migrate` създава компаниите, автомобилите, документите, правата, съобщенията и журнала.

## 4. Главен администратор

```bash
npm run create-admin -- admin@example.com "StrongPass1!" "Петър Кочияшев"
```

Само главният администратор може:
- да създава потребители;
- да задава първоначална парола;
- да сменя парола;
- да задава компании, роли и права.

Самостоятелната смяна и нулиране на парола от потребител е блокирана в приложението.

## 5. Публикуване

След добавяне на Environment Variables във Vercel натиснете **Deploy** или изпратете нов commit към GitHub.

## 6. Файлове

Документите и снимките се записват във Vercel Blob като private blobs. В базата се пази само пътят на файла.

## 7. Напомняния

За създаване на известия 30, 14, 7 и 1 ден преди срока изпълнявайте ежедневно:

```sql
select generate_document_notifications();
```

Може да се използва Vercel Cron, който извиква защитен API endpoint.

## Сигурност

- Базата не е достъпна директно от браузъра.
- Всички заявки минават през Next.js сървъра.
- Паролите се хешират от Better Auth.
- `DATABASE_URL` и Blob token са само във Vercel Environment Variables.
- Препоръчва се MFA за Vercel и Neon акаунтите.
