import Link from "next/link";
import { Building2,Car,ClipboardList,Gauge,Wrench,WalletCards,Users,BarChart3,MessageSquare,ShieldCheck,Settings,UserRound } from "lucide-react";
const links=[
["/dashboard","Начално табло",Gauge],["/companies","Компании",Building2],["/vehicles","Автомобили",Car],
["/documents","Документи",ClipboardList],["/service","Сервиз",Wrench],["/expenses","Разходи",WalletCards],
["/drivers","Шофьори",UserRound],["/reports","Справки",BarChart3],["/users","Потребители и права",Users],
["/messages","Съобщения",MessageSquare],["/audit","Журнал",ShieldCheck],["/settings","Настройки",Settings]
] as const;
export function Sidebar(){return <aside className="sidebar"><div className="brand"><div className="brand-logo">FM</div><div><strong>Fleet Manager</strong><small>Управление на автопарк</small></div></div><nav className="nav">{links.map(([href,label,Icon])=><Link href={href} key={href}><Icon size={18} style={{marginRight:9,verticalAlign:"middle"}}/>{label}</Link>)}</nav></aside>}
