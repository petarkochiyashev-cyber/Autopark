"use client";
import { authClient } from "@/lib/auth-client";
import { useRouter } from "next/navigation";
export function SignOutButton(){const router=useRouter();return <button className="btn btn-secondary" onClick={async()=>{await authClient.signOut();router.push("/login");router.refresh()}}>Изход</button>}
