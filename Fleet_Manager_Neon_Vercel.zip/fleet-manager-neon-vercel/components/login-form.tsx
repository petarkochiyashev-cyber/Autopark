"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";

export function LoginForm() {
  const router = useRouter();
  const [error,setError]=useState("");
  const [busy,setBusy]=useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const form=new FormData(event.currentTarget);
    const result=await authClient.signIn.email({
      email:String(form.get("email")||""),
      password:String(form.get("password")||""),
    });
    setBusy(false);
    if(result.error){setError("Невалиден имейл или парола.");return}
    router.push("/dashboard"); router.refresh();
  }

  return <form onSubmit={submit} className="grid">
    {error&&<div className="alert">{error}</div>}
    <div className="field"><label htmlFor="email">Имейл</label><input id="email" name="email" type="email" required /></div>
    <div className="field"><label htmlFor="password">Парола</label><input id="password" name="password" type="password" required /></div>
    <button disabled={busy} className="btn btn-primary">{busy?"Влизане...":"Вход"}</button>
  </form>;
}
