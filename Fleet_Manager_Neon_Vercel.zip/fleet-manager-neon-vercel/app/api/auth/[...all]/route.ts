import { toNextJsHandler } from "better-auth/next-js";
import { auth } from "@/lib/auth";

const handler = toNextJsHandler(auth);

// В този MVP потребителите не могат сами да сменят или нулират паролата си.
// Главният администратор използва защитения /api/admin/users endpoint.
const blocked = [
  "/change-password",
  "/request-password-reset",
  "/reset-password",
  "/forget-password",
];

export const GET = handler.GET;

export async function POST(request: Request) {
  const pathname = new URL(request.url).pathname;
  if (blocked.some((part) => pathname.endsWith(part))) {
    return Response.json(
      { error: "Паролите се управляват само от главния администратор." },
      { status: 403 }
    );
  }
  return handler.POST(request);
}
