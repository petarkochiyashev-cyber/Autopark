import { LoginForm } from "@/components/login-form";
import { getSessionContext } from "@/lib/session";
import { redirect } from "next/navigation";

export default async function LoginPage(){
  const ctx=await getSessionContext();
  if(ctx) redirect("/dashboard");
  return <main className="login-wrap"><section className="login-card">
    <div className="brand" style={{color:"#172033",padding:0,marginBottom:20}}>
      <div className="brand-logo" style={{color:"white"}}>FM</div>
      <div><strong>Fleet Manager</strong><small style={{color:"#68748a"}}>Управление на автопарк</small></div>
    </div>
    <h1 style={{fontSize:24}}>Вход</h1>
    <p className="muted">Профилите и паролите се създават от главния администратор.</p>
    <LoginForm />
  </section></main>;
}
