import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Fleet Manager",
  description: "Управление на фирмен автопарк",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="bg"><body>{children}</body></html>;
}
